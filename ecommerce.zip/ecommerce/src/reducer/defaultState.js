export const defaultState = {
  cart: [],
  amount: 0,
  totalCost: 0,
  totalCartSize: 0,
  showSidebar: false,
  screenWidth: window.innerWidth,
  showingOverlay: false,
  showingCart: false
}
