import Main from "./Main"
import Navigator from "./Navigator"
import Sidebar from "./Sidebar"
import Product from "./Product"

export { Main, Navigator, Sidebar, Product }
